﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DomainInfo
{
    internal class UserAndRoleAD
    {
        public string domain { get; set; }
        //public List<string> PropertyNames { get; }
        public List<string> Users { get; }
        public List<User> UsersCollection;

        public UserAndRoleAD(string _domain)
        {
            List<User> _UsersCollection = new List<User>();
            domain = _domain;
            PrincipalContext contextUser = new PrincipalContext(ContextType.Domain, domain);
            bool i = false;
           
            List<string> _Users = new List<string>();
            using (var context = new PrincipalContext(ContextType.Domain, domain))
            {
                using (var searcher = new PrincipalSearcher(new UserPrincipal(context)))
                {

                    foreach (var result in searcher.FindAll())
                    {
                        List<string> _PropertyNames = new List<string>();
                        DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;

                       
                            var a = de.Properties.PropertyNames;

                            foreach (var t in a)
                            {
                                _PropertyNames.Add(t.ToString());
                            }
                         
                        User user = new User();
                        user.name = de.Properties["sAMAccountName"].Value.ToString();
                        Dictionary<string, string> property = new Dictionary<string, string>();
                        foreach (var name in _PropertyNames)
                        {

                            
                        if (de.Properties[name.ToString()].Value!=null)
                        property.Add(name.ToString(), de.Properties[name.ToString()].Value.ToString());
                       

                        user.keyValue=property;
                        }
                        _Users.Add(de.Properties["sAMAccountName"].Value.ToString());
                        List<string> UserGroups = new List<string>();
                        UserPrincipal p = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, de.Properties["samAccountName"].Value.ToString());

                        if (p != null)
                        {
                            var groups = p.GetGroups();

                            foreach (var group in groups)
                            {
                                UserGroups.Add(@group.Name);

                            }
                        }
                        user.groups = UserGroups;
                        _UsersCollection.Add(user);
                    }

                }

            }
            //PropertyNames = _PropertyNames;
            Users = _Users;
            UsersCollection = _UsersCollection;
        }




        public void localAdmins()
        {
            DirectoryEntry entry = new DirectoryEntry("LDAP://" + domain);
            DirectorySearcher mySearcher = new DirectorySearcher(entry);
            mySearcher.Filter = ("(objectClass=computer)");
            mySearcher.SizeLimit = int.MaxValue;
            mySearcher.PageSize = int.MaxValue;

            foreach (SearchResult resEnt in mySearcher.FindAll())
            {

                string ComputerName = resEnt.GetDirectoryEntry().Name;
                if (ComputerName.StartsWith("CN="))
                    ComputerName = ComputerName.Remove(0, "CN=".Length);
                Console.WriteLine(ComputerName + ":   ");
                try
                {
                    DirectoryEntry localMachine = new DirectoryEntry("WinNT://" + ComputerName);
                    DirectoryEntry admGroup = localMachine.Children.Find("Администраторы", "group");

                    object members = admGroup.Invoke("members", null);

                    Console.WriteLine("Локальные администраторы:");
                    foreach (object groupMember in (IEnumerable)members)
                    {
                        DirectoryEntry member = new DirectoryEntry(groupMember);
                        Console.WriteLine(member.Name);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message.ToString());
                }



            }
        }
       
    }
}
