﻿using System;
using System.Collections.Generic;
using System.DirectoryServices.ActiveDirectory;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Windows.Forms;

namespace DomainInfo
{
    internal class UserAndRoleLocal
    {
        public string domain { get; set; }

        public List<Computer> ComputersCollection;
        public UserAndRoleLocal(string _domain)
        {
            List<Computer> _ComputersCollection = new List<Computer>();
            domain = _domain;
            DirectoryEntry entry = new DirectoryEntry("LDAP://" + _domain);
            DirectorySearcher mySearcher = new DirectorySearcher(entry);
            mySearcher.Filter = ("(objectClass=computer)");
            mySearcher.SizeLimit = int.MaxValue;
            mySearcher.PageSize = int.MaxValue;
            foreach (SearchResult resEnt in mySearcher.FindAll())
            {

                string ComputerName = resEnt.GetDirectoryEntry().Name;
                if (ComputerName.StartsWith("CN="))
                    ComputerName = ComputerName.Remove(0, "CN=".Length);
                //Console.WriteLine(ComputerName + ":   ");
                try
                {
                    DirectoryEntry localMachine = new DirectoryEntry("WinNT://" + ComputerName);
                    DirectoryEntry admGroup = localMachine.Children.Find("Администраторы", "group");

                    object members = admGroup.Invoke("members", null);

                    Computer computer = new Computer();
                    computer.name = ComputerName;
                    // Console.WriteLine("Локальные администраторы:");
                    foreach (object groupMember in (IEnumerable)members)
                    {
                        try
                        {
                            DirectoryEntry member = new DirectoryEntry(groupMember);
                            //Console.WriteLine(member.Name);
                            computer.UserGroups.Add(member.Name);
                        }
                        catch (Exception ex)
                        {
                            computer.UserGroups.Add(ex.Message);
                        }
                    }


                    _ComputersCollection.Add(computer);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                    //Console.WriteLine(ex.Message.ToString());
                }



            }
            ComputersCollection = _ComputersCollection;
        }

    }
}
