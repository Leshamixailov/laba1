﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Management;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DomainInfo
{
    public partial class Start : Form
    {
        public Start()
        {
           
            InitializeComponent();
            //textBox1.Text = sha256("To be filled by O.E.M." + "pirat");
            try
            {
                textBox2.Text = CreateMD5(GetBoardSerialNumbers());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        public static string CreateMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                var hash = new System.Text.StringBuilder();

                foreach (byte theByte in hashBytes)
                {
                    hash.Append(theByte.ToString("x2"));
                }
                return hash.ToString();
                // Convert the byte array to hexadecimal string prior to .NET 5
                // StringBuilder sb = new System.Text.StringBuilder();
                // for (int i = 0; i < hashBytes.Length; i++)
                // {
                //     sb.Append(hashBytes[i].ToString("X2"));
                // }
                // return sb.ToString();
            }
        }
        private string GetBoardSerialNumbers()
        {
            List<string> results = new List<string>();

            string query = "SELECT * FROM Win32_BaseBoard";
            ManagementObjectSearcher searcher =
                new ManagementObjectSearcher(query);
            foreach (ManagementObject info in searcher.Get())
            {
                results.Add(
                    info.GetPropertyValue("SerialNumber").ToString());
            }

            return results[0];
        }
        static string sha256(string randomString)
        {
            var crypt = new System.Security.Cryptography.SHA256Managed();
            var hash = new System.Text.StringBuilder();
            byte[] crypto = crypt.ComputeHash(Encoding.UTF8.GetBytes(randomString));
            foreach (byte theByte in crypto)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox1.Text == sha256(CreateMD5(GetBoardSerialNumbers()) + "pirat"))
                {
                    Form1 form = new Form1();
                    form.Show();
                }
                else
                {
                    MessageBox.Show("Неправильный Мастер Ключ");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
    }
}
