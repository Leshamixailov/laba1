﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Interop;
using static System.Net.Mime.MediaTypeNames;

namespace DomainInfo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var crypt = new SHA256Managed();
            dataGridView1.MultiSelect = false;
            toolStripButton4.Enabled = false;
            toolStripButton2.Enabled = false;
        }

        List<User> users = new List<User>();
        List<Computer> computers = new List<Computer>();

        bool StartSelect = false;
        bool StartSelect1 = false;
        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (textBox4.Text != "")
                {
                    computers.Clear();
                    StartSelect1 = false;
                    dataGridView2.Rows.Clear();
                    dataGridView4.Rows.Clear();

                    UserAndRoleLocal userAndRolelocal = new UserAndRoleLocal(textBox4.Text);

                    foreach (var computer in userAndRolelocal.ComputersCollection)
                    {
                        dataGridView2.Rows.Add(computer.name);
                    }



                    computers = userAndRolelocal.ComputersCollection;
                    toolStripButton2.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Укажите домен");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox3.Text != "")
                {
                    users.Clear();
                    StartSelect = false;
                    dataGridView1.Rows.Clear();
                    dataGridView3.Rows.Clear();
                    textBox1.Clear();
                    UserAndRoleAD userAndRoleAD = new UserAndRoleAD(textBox3.Text);

                    foreach (var user in userAndRoleAD.Users)
                    {
                        dataGridView1.Rows.Add(user);
                    }



                    users = userAndRoleAD.UsersCollection;
                    toolStripButton4.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Укажите домен");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }


        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (!StartSelect)
                {
                    StartSelect = true;
                }
                else if (dataGridView1.Rows[dataGridView1.SelectedCells[0].RowIndex].Cells[0].Value != null)
                {
                    dataGridView3.Rows.Clear();
                    StartSelect = false;
                    string text = "";
                    User usr = users.Where(a => a.name == dataGridView1.Rows[dataGridView1.SelectedCells[0].RowIndex].Cells[0].Value.ToString()).FirstOrDefault();
                    foreach (var key in usr.keyValue)
                    {
                        text += key.Key.ToString() + " : " + key.Value.ToString() + Environment.NewLine;

                    }
                    textBox1.Text = text.ToString();
                    foreach (var grop in usr.groups)
                    {

                        dataGridView3.Rows.Add(grop);

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt";
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // получаем выбранный файл
            string filename = saveFileDialog1.FileName;
            string text = "";
            using (FileStream fstream = new FileStream(filename, FileMode.Create))
            {




                foreach (var usr in users)
                {

                    foreach (var key in usr.keyValue)
                    {
                        text += key.Key.ToString() + " : " + key.Value.ToString() + "\n";

                    }

                    foreach (var grop in usr.groups)
                    {
                        text += "Член групы" + " : " + grop + "\n";
                    }
                    text += "__________________________________________________________________________________\n";
                    byte[] buffer = Encoding.Default.GetBytes(text);

                    fstream.Write(buffer, 0, buffer.Length);

                }
            }

            System.IO.File.WriteAllText(filename, text);
            MessageBox.Show("Файл сохранен");
        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {

            try
            {
                if (!StartSelect1)
                {
                    StartSelect1 = true;
                }
                else if (dataGridView2.Rows[dataGridView2.SelectedCells[0].RowIndex].Cells[0].Value != null)
                {
                    //MessageBox.Show(dataGridView2.Rows[dataGridView2.SelectedCells[0].RowIndex].Cells[0].Value.ToString());
                    dataGridView4.Rows.Clear();

                    //        string text = "";
                    Computer comp = computers.Where(a => a.name == dataGridView2.Rows[dataGridView2.SelectedCells[0].RowIndex].Cells[0].Value.ToString()).FirstOrDefault();

                    foreach (var gruop in comp.UserGroups)
                    {

                        dataGridView4.Rows.Add(gruop);

                    }


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt";
            if (saveFileDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            // получаем выбранный файл
            string filename = saveFileDialog1.FileName;
            string text = "";
            using (FileStream fstream = new FileStream(filename, FileMode.Create))
            {




                foreach (var comp in computers)
                {
                    text += comp.name+ "\n";
                    text += "Локальные администраторы:\n";
                    foreach (var grop in comp.UserGroups)
                    {
                        text += "Член групы" + " : " + grop + "\n";
                    }
                    text += "__________________________________________________________________________________\n";
                    byte[] buffer = Encoding.Default.GetBytes(text);

                    fstream.Write(buffer, 0, buffer.Length);

                }
            }

            System.IO.File.WriteAllText(filename, text);
            MessageBox.Show("Файл сохранен");
        }
    }
}
