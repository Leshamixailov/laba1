﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainInfo
{
    internal class User
    {
      

        public List<string> groups = new List<string>();
        public Dictionary<string, string> keyValue = new Dictionary<string, string>();
        public string name { get; set; }
    }
}
