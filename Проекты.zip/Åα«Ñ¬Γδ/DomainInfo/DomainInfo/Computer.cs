﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainInfo
{
    internal class Computer
    {
        public List<string> UserGroups = new List<string>();
       
        public string name { get; set; }
    }
}
