﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ShareDetector
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void добавитьToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            TreeNode division = new TreeNode( textBox2.Text);
            treeView1.Nodes.Add( division );
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TreeNode node = treeView1.SelectedNode;
            if(node != null)
            {
                int level = treeView1.SelectedNode.Level;
                if (level == 0)
                {
                    for (int i = Convert.ToInt32(textBox3.Text); i < Convert.ToInt32(textBox4.Text); i++)
                    {
                        TreeNode ip = new TreeNode(textBox1.Text+i.ToString());
                        treeView1.Nodes[node.Index].Nodes.Add(ip);
                    }
                   
                }
            }
           
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string dir = "\\\\"+treeView1.Nodes[0].Nodes[0].Text.ToString()+"\\";
            //string[] lst = Directory.GetDirectories(dir);
            //foreach (string path in lst)
            //{
            //    MessageBox.Show(path);
            //}
            using (ManagementClass shares = new ManagementClass(dir, "Win32_Share", new ObjectGetOptions()))
            {
                foreach (ManagementObject share in shares.GetInstances())
                {
                    MessageBox.Show(share["Name"].ToString());
                }
            }
        }
    }
}
