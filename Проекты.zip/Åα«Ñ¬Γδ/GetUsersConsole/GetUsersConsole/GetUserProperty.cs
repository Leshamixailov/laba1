﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using System.Linq.Expressions;

namespace GetUsersConsole
{
    internal class GetUserProperty
    {
        public GetUserProperty(string domain)
        {
            _domain = domain;

        }
        private string _domain { get; set; }



        
        public void localAdmins()
        {
            DirectoryEntry entry = new DirectoryEntry("LDAP://"+_domain);
            DirectorySearcher mySearcher = new DirectorySearcher(entry);
            mySearcher.Filter = ("(objectClass=computer)");
            mySearcher.SizeLimit = int.MaxValue;
            mySearcher.PageSize = int.MaxValue;

            foreach (SearchResult resEnt in mySearcher.FindAll())
            {
                
                string ComputerName = resEnt.GetDirectoryEntry().Name;
                if (ComputerName.StartsWith("CN="))
                    ComputerName = ComputerName.Remove(0, "CN=".Length);
                Console.WriteLine(ComputerName + ":   ");
                try
                    {
                    DirectoryEntry localMachine = new DirectoryEntry("WinNT://" + ComputerName);
                    DirectoryEntry admGroup = localMachine.Children.Find("Администраторы", "group");

                    object members = admGroup.Invoke("members", null);

                    Console.WriteLine("Локальные администраторы:");
                    foreach (object groupMember in (IEnumerable)members)
                    {
                        DirectoryEntry member = new DirectoryEntry(groupMember);
                        Console.WriteLine(member.Name);
                    }
                    }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message.ToString());
                }
                
                

            }
        }
        public void AdUsers()
        {
            try
            {
                PrincipalContext contextUser = new PrincipalContext(ContextType.Domain, _domain);
                bool i = false;
                List<string> PropertyNames = new List<string>();
                using (var context = new PrincipalContext(ContextType.Domain, _domain))
                {
                    using (var searcher = new PrincipalSearcher(new UserPrincipal(context)))
                    {

                        foreach (var result in searcher.FindAll())
                        {
                            DirectoryEntry de = result.GetUnderlyingObject() as DirectoryEntry;

                            if (!i)
                            {
                                var a = de.Properties.PropertyNames;

                                foreach (var t in a)
                                {
                                    PropertyNames.Add(t.ToString());
                                }
                                i = true;
                            }
                            foreach (var name in PropertyNames)
                            {

                                Console.WriteLine(name + " : " + de.Properties[name.ToString()].Value);

                            }

                            UserPrincipal p = UserPrincipal.FindByIdentity(context, IdentityType.SamAccountName, de.Properties["samAccountName"].Value.ToString());

                            if (p != null)
                            {
                                var groups = p.GetGroups();

                                foreach (var group in groups)
                                {
                                    Console.WriteLine("Group name: " + @group.Name);

                                }
                            }

                            Console.WriteLine();
                        }

                    }

                }


            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
            }
           
        }
    }
}
