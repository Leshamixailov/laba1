﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetUsersConsole
{
    internal class Program
    {

       
        static void Main(string[] args)
        {
            if (args.Length == 0)
            {
                System.Console.WriteLine("Отсуствует аргумент указывающий на домен");
            }
            if (args.Length == 1)
            {
                GetUserProperty getUserProperty = new GetUserProperty(args[0]);
                getUserProperty.AdUsers();
            }
            if (args.Length == 2)
            {
                if (args[1] == "localadmins")
                {
                    GetUserProperty getUserProperty = new GetUserProperty(args[0]);
                    getUserProperty.localAdmins();
                }
                
            }





        }
    }
}
